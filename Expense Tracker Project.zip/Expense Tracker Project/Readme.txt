1. Before starting this code you need to run this command in your terminal

---> pip install colorama   

2. Then execute the code with this

---> python main.py

