import sqlite3

def init_db():
    conn = sqlite3.connect('expense_tracker.db')
    cursor = conn.cursor()

    cursor.execute('''CREATE TABLE IF NOT EXISTS expenses (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        amount REAL NOT NULL,
                        category_id INTEGER NOT NULL,
                        description TEXT,
                        date TEXT NOT NULL,
                        FOREIGN KEY (category_id) REFERENCES categories(id))''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS income (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        amount REAL NOT NULL,
                        source TEXT NOT NULL,
                        date TEXT NOT NULL)''')

    cursor.execute('''CREATE TABLE IF NOT EXISTS categories (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT UNIQUE NOT NULL)''')

    cursor.execute("INSERT OR IGNORE INTO categories (name) VALUES ('Food'), ('Transport'), ('Entertainment'), ('Rent'), ('Misc')")

    cursor.execute('''CREATE TABLE IF NOT EXISTS balance (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        total_income REAL DEFAULT 0,
                        total_expenses REAL DEFAULT 0,
                        current_balance REAL DEFAULT 0)''')

    conn.commit()
    conn.close()

def get_db_connection():
    return sqlite3.connect('expense_tracker.db')
