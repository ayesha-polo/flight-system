from db import get_db_connection
from datetime import datetime

def add_expense():
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        amount = float(input("Enter expense amount: "))
        category = input("Enter category (e.g., Food, Transport): ").capitalize()
        description = input("Enter a description (optional): ")
        date = input("Enter the date (YYYY-MM-DD), or leave blank for today: ")

        if not date:
            date = datetime.today().strftime('%Y-%m-%d')

        cursor.execute("SELECT id FROM categories WHERE name = ?", (category,))
        category_id = cursor.fetchone()

        if category_id:
            cursor.execute("INSERT INTO expenses (amount, category_id, description, date) VALUES (?, ?, ?, ?)",
                           (amount, category_id[0], description, date))
            cursor.execute("UPDATE balance SET total_expenses = total_expenses + ?, current_balance = current_balance - ?", (amount, amount))
            conn.commit()
            print("Expense added successfully!")
        else:
            print("Invalid category. Please use a predefined category.")

    except ValueError:
        print("Invalid input. Please enter a valid number for the amount.")

    conn.close()


def add_income():
    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        amount = float(input("Enter income amount: "))
        source = input("Enter income source: ")
        date = input("Enter the date (YYYY-MM-DD), or leave blank for today: ")

        if not date:
            date = datetime.today().strftime('%Y-%m-%d')

        cursor.execute("INSERT INTO income (amount, source, date) VALUES (?, ?, ?)", (amount, source, date))
        cursor.execute("UPDATE balance SET total_income = total_income + ?, current_balance = current_balance + ?", (amount, amount))
        conn.commit()
        print("Income added successfully!")

    except ValueError:
        print("Invalid input. Please enter a valid number for the amount.")

    conn.close()


def view_expenses():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute('''SELECT expenses.amount, categories.name, expenses.description, expenses.date 
                      FROM expenses JOIN categories ON expenses.category_id = categories.id''')
    expenses = cursor.fetchall()

    if expenses:
        print("\nAmount | Category | Description | Date")
        print("-------------------------------------------")
        for expense in expenses:
            print(f"{expense[0]:.2f} | {expense[1]} | {expense[2] or 'N/A'} | {expense[3]}")
    else:
        print("No expenses found.")

    conn.close()


def view_income():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM income")
    income = cursor.fetchall()

    if income:
        print("\nID | Amount | Source | Date")
        print("-------------------------------")
        for inc in income:
            print(f"{inc[0]} | {inc[1]:.2f} | {inc[2]} | {inc[3]}")
    else:
        print("No income records found.")

    conn.close()


def calculate_total(timeframe, table='expenses'):
    conn = get_db_connection()
    cursor = conn.cursor()

    today = datetime.today().strftime('%Y-%m-%d')
    if timeframe == 'daily':
        cursor.execute(f"SELECT SUM(amount) FROM {table} WHERE date = ?", (today,))
    elif timeframe == 'monthly':
        month = today[:7]  # YYYY-MM
        cursor.execute(f"SELECT SUM(amount) FROM {table} WHERE date LIKE ?", (month + '%',))
    elif timeframe == 'yearly':
        year = today[:4]  # YYYY
        cursor.execute(f"SELECT SUM(amount) FROM {table} WHERE date LIKE ?", (year + '%',))

    total = cursor.fetchone()[0] or 0
    print(f"Total {timeframe} {'expenses' if table == 'expenses' else 'income'}: {total:.2f}")

    conn.close()


def view_balance():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT total_income, total_expenses, current_balance FROM balance")
    balance = cursor.fetchone()
    if balance:
        print(f"\nTotal Income: {balance[0]:.2f}")
        print(f"Total Expenses: {balance[1]:.2f}")
        print(f"Current Balance: {balance[2]:.2f}")
    else:
        print("No balance data available.")

    conn.close()
