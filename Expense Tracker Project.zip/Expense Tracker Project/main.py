import os
from helper_functions import add_expense, add_income, view_expenses, view_income, calculate_total, view_balance
from db import init_db
from colorama import init, Fore, Style


init(autoreset=True)

# Clear the terminal screen based on the operating system
def clear_screen():
    if os.name == 'nt':  # For Windows
        os.system('cls')
    else:  # For Linux and Mac
        os.system('clear')

def wait_for_input():
    input(Fore.YELLOW + "\nPress Enter to return to the main menu...")


def main_menu():
    while True:
        clear_screen() 
        print(Fore.CYAN + Style.BRIGHT + "\n=== Personal Expense Tracker ===")
        print(Fore.GREEN + "1. Add Expense")
        print(Fore.GREEN + "2. Add Income")
        print(Fore.GREEN + "3. View Expenses")
        print(Fore.GREEN + "4. View Income")
        print(Fore.GREEN + "5. Calculate Total Expenses (Daily, Monthly, Yearly)")
        print(Fore.GREEN + "6. Calculate Total Income (Daily, Monthly, Yearly)")
        print(Fore.GREEN + "7. View Balance")
        print(Fore.RED + "8. Exit")
        
        choice = input(Fore.CYAN + Style.BRIGHT + "\nSelect an option: ")

        if choice == '1':
            clear_screen()
            handle_option(add_expense, "Add Expense")
        elif choice == '2':
            clear_screen()
            handle_option(add_income, "Add Income")
        elif choice == '3':
            clear_screen()
            handle_option(view_expenses, "View Expenses")
        elif choice == '4':
            clear_screen()
            handle_option(view_income, "View Income")
        elif choice == '5':
            clear_screen()
            handle_calculate("expenses")
        elif choice == '6':
            clear_screen()
            handle_calculate("income")
        elif choice == '7':
            clear_screen()
            view_balance()
            wait_for_input()
        elif choice == '8':
            clear_screen()
            print(Fore.RED + "Exiting... Goodbye!")
            break
        else:
            print(Fore.RED + "Invalid option! Please try again.")
            wait_for_input()


def handle_option(action, option_name):
    while True:
        clear_screen()
        print(Fore.CYAN + f"=== {option_name} ===")
        action()
        back_choice = input(Fore.YELLOW + "\nDo you want to go back to the main menu? (yes/no): ").lower()
        if back_choice == 'yes':
            break


def handle_calculate(table):
    while True:
        timeframe = input(Fore.CYAN + "Enter timeframe (daily, monthly, yearly) or type 'back' to return to the main menu: ").lower()
        if timeframe == 'back':
            break
        elif timeframe in ['daily', 'monthly', 'yearly']:
            calculate_total(timeframe, table)
            wait_for_input()
            break
        else:
            print(Fore.RED + "Invalid timeframe! Please enter 'daily', 'monthly', 'yearly', or 'back'.")

if __name__ == "__main__":
    init_db()
    main_menu()
